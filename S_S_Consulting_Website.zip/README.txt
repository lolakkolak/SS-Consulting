S & S Consulting Website
==========================

Diese Website besteht nur aus HTML, CSS und JavaScript und funktioniert ohne Framework oder Installation.

Dateien:
- index.html ........ Hauptseite
- styles.css ........ Design & Responsive Layout
- script.js ......... Animationen, Menü, Zähler
- impressum.html .... Impressum-Vorlage
- datenschutz.html .. Datenschutz-Vorlage
- assets/logo.png ... Logo

So startest du:
1. ZIP entpacken.
2. index.html doppelklicken.
3. Für Veröffentlichung alle Dateien auf deinen Webspace hochladen.

Wichtig vor Veröffentlichung:
- Telefonnummer ersetzen.
- E-Mail-Adresse prüfen/anpassen.
- Impressum mit echten Unternehmensdaten ergänzen.
- Datenschutzerklärung an den tatsächlichen Hosting-Anbieter und verwendete Dienste anpassen.
- Das Kontaktformular nutzt aktuell mailto: und öffnet das E-Mail-Programm des Besuchers.
  Für echten Formularversand ohne Mail-Programm kann später ein Dienst wie Formspree/Netlify Forms
  oder ein eigener Backend-Endpunkt eingebunden werden.

Geeignet für:
- IONOS / STRATO / All-Inkl / Hetzner Webhosting
- Netlify / Cloudflare Pages / GitHub Pages
- praktisch jeden normalen Webserver, da keine Server-Software erforderlich ist.
